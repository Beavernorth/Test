export const EVENT_NAMES = {
  SELECT_INSURANCE_TYPE: "select_insurance_type",
  CONFIRM_INSURANCE_SUBMIT: "confirm_insurance_submit",
};
