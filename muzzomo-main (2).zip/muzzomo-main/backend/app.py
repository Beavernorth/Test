from http import HTTPStatus

import flask
from flask_cors import CORS
from markupsafe import escape

from src.utils.utm_fields import UtmFields

app = flask.Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD'] = True
app.secret_key = "bogusKeyPleaseUpdateMe"

cors = CORS(app, resources={r"/api/*": {"origins": "https://muzzomo.com"}})


@app.route("/api/health", methods=["GET"])
def health():
    request_params = flask.request.args
    flask.session[UtmFields.UTM_FIELDS] = dict()
    for param in UtmFields().get_all():
        if param in request_params:
            param_value = escape(request_params[param])
        else:
            param_value = "null"
        flask.session[UtmFields.UTM_FIELDS][param] = param_value

    flask.session.modified = True
    return flask.jsonify(status="success"), HTTPStatus.OK


# Please keep these imports. They are necessary (for now) to use the routes
# specified in other route files
from src.routes.adviser_endpoints import *
from src.routes.client_endpoints import *
from src.routes.error_handlers import *
