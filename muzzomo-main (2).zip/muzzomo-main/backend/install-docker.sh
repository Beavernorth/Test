sudo apt-add-repository -r ppa:certbot/certbot
sudo apt update
sudo apt-get update
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
docker version
apt  install docker-compose