from app import app
from src.utils import db_utils

if __name__ == "__main__":
    db_utils.DatabaseUtils("database.db").setup_local_db()
    app.run(debug=False, host="0.0.0.0", port=8080)
