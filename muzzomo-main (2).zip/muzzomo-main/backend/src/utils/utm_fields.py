
class UtmFields:
    UTM_FIELDS = "utm_fields"
    UTM_CAMPAIGN = "utm_campaign"
    UTM_ID = "utm_id"
    UTM_LOCATION = "utm_location"
    UTM_MEDIUM = "utm_medium"
    UTM_SOURCE = "utm_source"

    def get_all(self):
        return [
            self.UTM_CAMPAIGN,
            self.UTM_ID,
            self.UTM_LOCATION,
            self.UTM_MEDIUM,
            self.UTM_SOURCE
        ]

    def get_default_utm_fields(self):
        return {
            self.UTM_CAMPAIGN: "null",
            self.UTM_ID: "null",
            self.UTM_LOCATION: "null",
            self.UTM_MEDIUM: "null",
            self.UTM_SOURCE: "null"
        }
