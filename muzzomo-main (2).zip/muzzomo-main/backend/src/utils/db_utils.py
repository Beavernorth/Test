import sqlite3
from markupsafe import escape

from src.utils.utm_fields import UtmFields

CREATE_CLIENTS_TABLE = \
    """CREATE TABLE IF NOT EXISTS clients (
    id INTEGER PRIMARY KEY AUTOINCREMENT, uuid VARCHAR(200), first_name VARCHAR(200), last_name VARCHAR(200), 
    gender VARCHAR(200), dob DATE, postal_code VARCHAR(200), email VARCHAR(200), num_children INTEGER DEFAULT 0, 
    income INTEGER DEFAULT 0, in_debt BOOLEAN DEFAULT false, is_smoker BOOLEAN DEFAULT false, 
    insurance_type VARCHAR(200), created_date DATE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (uuid)
    )"""

CREATE_ADVISERS_TABLE = \
    """CREATE TABLE IF NOT EXISTS advisers (
    id INTEGER PRIMARY KEY AUTOINCREMENT, first_name VARCHAR(200), last_name VARCHAR(200), gender VARCHAR(200), 
    firm VARCHAR(200), firm_location VARCHAR(200), email VARCHAR(200), created_date DATE DEFAULT CURRENT_TIMESTAMP
    )"""

CREATE_MARKETING_TABLE = \
    """CREATE TABLE IF NOT EXISTS marketing (
    id INTEGER PRIMARY KEY AUTOINCREMENT, client_id VARCHAR(200) NOT NULL, 
    utm_campaign VARCHAR(200), utm_id VARCHAR(200), utm_medium VARCHAR(200), utm_source VARCHAR(200),
    FOREIGN KEY (client_id) REFERENCES clients(uuid) ON DELETE CASCADE
    )"""

ADD_SAMPLE_ADVISER = \
    """INSERT INTO advisers (
    first_name, last_name, gender, firm, firm_location, email
    ) VALUES (
    'Jake', 'De Franco', 'Male', 'MyFirm.com', 'LOCATION', 'advisor.defranco@gmail.com'
    )"""

ADD_SAMPLE_CLIENT = \
    """INSERT INTO clients (
    uuid, first_name, last_name, gender, dob, postal_code, email, insurance_type
    ) VALUES (
    '1234ABCD', 'Jake', 'De Franco', 'Male', '1997-11-16', 'LOCATION', 'client.defranco@gmail.com', 'auto'
    )"""


ADD_SAMPLE_MARKETING_ROW = \
    """INSERT INTO marketing (
    client_id, utm_campaign, utm_id, utm_medium, utm_source
    ) VALUES (
    '1234ABCD', 'null', '1', 'poster', 'null'
    )"""

SELECT_ALL = "SELECT * FROM {table_name}"

SELECT_ALL_WITH_CLIENT_ID = "SELECT * FROM {table_name} WHERE client_id=='{client_id}'"

INSERT_ADVISER =\
    """INSERT INTO advisers (
    first_name, last_name, gender, firm, firm_location, email
    ) VALUES (
    '{first_name}', '{last_name}', '{gender}', '{firm}', '{firm_location}', '{email}'
    )"""

INSERT_CLIENT = \
    """INSERT INTO clients (
    uuid, first_name, last_name, gender, dob, postal_code, email, insurance_type, num_children, 
    income, in_debt, is_smoker
    ) VALUES (
    '{uuid}', '{first_name}', '{last_name}', '{gender}', '{date_of_birth}', '{postal_code}', '{email}', 
    '{insurance_type}', '{num_children}', '{income}', '{in_debt}', '{is_smoker}'
    )"""


INSERT_MARKETING_ROW = \
    """INSERT INTO marketing (
    client_id, utm_campaign, utm_id, utm_location, utm_medium, utm_source
    ) VALUES (
    '{client_id}', '{utm_campaign}', '{utm_id}', '{utm_location}', '{utm_medium}', '{utm_source}'
    )"""


class DatabaseUtils:

    DEFAULT_DB_FILE_NAME = "database.db"
    TABLE_LIST = {
        "advisers": {
            "create": CREATE_ADVISERS_TABLE,
            # "sample": ADD_SAMPLE_ADVISER
        },
        "clients": {
            "create": CREATE_CLIENTS_TABLE,
            # "sample": ADD_SAMPLE_CLIENT
        },
        "marketing": {
            "create": CREATE_MARKETING_TABLE,
            # "sample": ADD_SAMPLE_MARKETING_ROW
        }
    }

    def __init__(self, db_file_name=None):
        self.db_file_name = db_file_name or self.DEFAULT_DB_FILE_NAME

    def create_connection(self):
        """ create a database connection to a SQLite database """
        return sqlite3.connect(self.db_file_name)

    def setup_local_db(self):
        db_connection = self.create_connection()
        db_cursor = db_connection.cursor()
        something_to_commit = False
        for table_name in self.TABLE_LIST:
            try:
                db_cursor.execute(self.TABLE_LIST[table_name]["create"])
                if self.TABLE_LIST[table_name].get("sample"):
                    db_cursor.execute(self.TABLE_LIST[table_name]["sample"])
                something_to_commit = True
                print(f"Created Table: {table_name}")
            except sqlite3.Error as e:
                if e.args[0] == f"table {table_name} already exists":
                    print(f"Table: {table_name}, already exists, skipping over it")
                else:
                    raise RuntimeError("Issue setting up the database", e)

        if something_to_commit:
            db_connection.commit()
        db_connection.close()

    def debug_table(self, table_name="clients"):
        db_connection = self.create_connection()
        print(f"TABLE: {table_name}")
        for row in db_connection.execute(SELECT_ALL.format(table_name=table_name)):
            print(row)
        db_connection.close()

    def add_client(
            self, client_id, first_name, last_name, gender, dob, postal_code, email, insurance_type,
            num_children=0, income=0, in_debt=False, is_smoker=False
    ):
        db_connection = self.create_connection()
        db_cursor = db_connection.cursor()
        db_cursor.execute(INSERT_CLIENT.format(
            uuid=client_id,
            first_name=escape(first_name),
            last_name=escape(last_name),
            gender=escape(gender),
            date_of_birth=escape(dob),
            postal_code=escape(postal_code),
            email=escape(email),
            insurance_type=escape(insurance_type),
            num_children=int(num_children),
            income=int(income),
            in_debt=bool(in_debt),
            is_smoker=bool(is_smoker),
        ))
        db_connection.commit()
        db_connection.close()

    @staticmethod
    def convert_client_row_to_json(client_row):
        return {
            "clientId": client_row[1],
            "firstName": client_row[2],
            "lastName": client_row[3],
            "gender": client_row[4],
            "dateOfBirth": client_row[5],
            "postalCode": client_row[6],
            "email": client_row[7],
            "insuranceType": client_row[8],
            "numChildren": client_row[9],
            "income": client_row[10],
            "inDebt": client_row[11],
            "isSmoker": client_row[12],
            "createdData": client_row[13],
        }

    def add_adviser(self, first_name, last_name, gender, firm, firm_location, email):
        db_connection = self.create_connection()
        db_cursor = db_connection.cursor()
        db_cursor.execute(INSERT_ADVISER.format(
            first_name=escape(first_name),
            last_name=escape(last_name),
            gender=escape(gender),
            firm=escape(firm),
            firm_location=escape(firm_location),
            email=escape(email)
        ))
        db_connection.commit()
        db_connection.close()

    @staticmethod
    def convert_adviser_row_to_json(adviser_row):
        return {
            "firstName": adviser_row[1],
            "lastName": adviser_row[2],
            "gender": adviser_row[3],
            "firm": adviser_row[4],
            "firmLocation": adviser_row[5],
            "email": adviser_row[6],
            "createdData": adviser_row[7],
        }

    def add_marketing_row(self, client_id, utm_fields):
        db_connection = self.create_connection()
        db_cursor = db_connection.cursor()
        db_cursor.execute(INSERT_MARKETING_ROW.format(
            client_id=escape(client_id),
            utm_campaign=utm_fields[UtmFields.UTM_CAMPAIGN],
            utm_id=utm_fields[UtmFields.UTM_ID],
            utm_location=utm_fields[UtmFields.UTM_LOCATION],
            utm_medium=utm_fields[UtmFields.UTM_MEDIUM],
            utm_source=utm_fields[UtmFields.UTM_SOURCE],
        ))
        db_connection.commit()
        db_connection.close()

    @staticmethod
    def convert_marketing_row_to_json(marketing_row):
        return {
            UtmFields.UTM_CAMPAIGN: marketing_row[2],
            UtmFields.UTM_ID: marketing_row[3],
            UtmFields.UTM_MEDIUM: marketing_row[4],
            UtmFields.UTM_SOURCE: marketing_row[5],
        }

    def get_all_advisers(self):
        db_connection = self.create_connection()
        data_map = []
        for row in db_connection.execute(SELECT_ALL.format(table_name="advisers")):
            data_map.append(row)
        db_connection.close()
        return data_map

    def get_all_clients(self):
        db_connection = self.create_connection()
        data_map = []
        for row in db_connection.execute(SELECT_ALL.format(table_name="clients")):
            data_map.append(row)
        db_connection.close()
        return data_map

    def get_all_marketing_rows(self):
        db_connection = self.create_connection()
        data_map = []
        for row in db_connection.execute(SELECT_ALL.format(table_name="marketing")):
            data_map.append(row)
        db_connection.close()
        return data_map

    def get_marketing_info_by_client(self, client_id):
        db_connection = self.create_connection()
        first_row = None
        for row in db_connection.execute(SELECT_ALL_WITH_CLIENT_ID.format(table_name="marketing", client_id=client_id)):
            if first_row is None:
                first_row = row
                break

        db_connection.close()
        return first_row

    def get_marketing_info_by_client_row(self, client_row):
        return self.get_marketing_info_by_client(client_row[1])
