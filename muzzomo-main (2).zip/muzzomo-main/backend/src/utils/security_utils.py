import base64
import hashlib


def get_hash_value(string):
    return hashlib.sha256(str.encode(string)).hexdigest()


def base64_encode(string):
    return base64.encodebytes(string)


def base64_decode(string):
    return base64.decodebytes(string)
