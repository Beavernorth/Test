from datetime import datetime
from http import HTTPStatus

import flask
from markupsafe import escape
from uuid import uuid4 as random_uuid

from app import app
from src.utils import db_utils
from src.utils import security_utils
from src.utils.utm_fields import UtmFields


@app.route("/api/add-client", methods=["POST"])
def add_client():
    data = flask.request.form

    request_validation_errors = validate_request_body(data)
    if len(request_validation_errors) > 0:
        response = {
            "status": "400:Bad Request",
            "errors": request_validation_errors
        }
        return flask.jsonify(response), HTTPStatus.BAD_REQUEST

    date_of_birth_str = data.get("dateOfBirth")
    if date_of_birth_str:
        date_of_birth = datetime.strptime(date_of_birth_str, "%d/%m/%Y")
    else:
        date_of_birth = datetime.today()

    client_id = random_uuid()
    database = db_utils.DatabaseUtils()
    database.add_client(
        client_id=client_id,
        first_name=data.get("firstName", "default-first-name"),
        last_name=data.get("lastName", "default-last-name"),
        gender=data.get("gender", "default-gender"),
        dob=date_of_birth.strftime("%Y-%m-%d"),
        postal_code=data.get("postalCode", "N/A"),
        email=data.get("email", "bogus@gmail.com"),
        insurance_type=data.get("insuranceType", "default"),
        num_children=data.get("numChildren", 0),
        income=data.get("income", 0),
        in_debt=data.get("inDebt", False),
        is_smoker=data.get("isSmoker", False),
    )
    database.add_marketing_row(
        client_id=client_id,
        utm_fields=flask.session.get(UtmFields.UTM_FIELDS, UtmFields().get_default_utm_fields())
    )
    flask.session.pop(UtmFields.UTM_FIELDS)
    return flask.jsonify(status="success"), HTTPStatus.CREATED


def validate_request_body(request_data):
    invalid_fields = []
    required_fields = ["firstName", "lastName", "email", "insuranceType", "postalCode", "dateOfBirth"]

    for field in required_fields:
        request_value = request_data.get(field)
        if request_value is None:
            invalid_fields.append({"field": field, "message": "Is a required field"})
        else:
            if not isinstance(request_value, str):
                invalid_fields.append({"field": field, "message": "must be a string"})

    date_of_birth = request_data.get("dateOfBirth")
    if date_of_birth:
        try:
            datetime.strptime(date_of_birth, "%d/%m/%Y")
        except ValueError as error:
            print(error)
            invalid_fields.append({"field": "dateOfBirth", "message": "Must be in DD/MM/YYYY format"})

    insurance_type = request_data.get("insuranceType")
    if insurance_type is not None:
        if insurance_type.lower().strip() not in ["auto", "business", "home", "life"]:
            invalid_fields.append(
                {"field": "insuranceType", "message": "Must be one of the following: [auto, business, home, life]"}
            )
    return invalid_fields


@app.route("/api/get-clients/<psw>", methods=["GET"])
def get_clients(psw):
    hashed_psw = "b989d62e5533b11cbc3464b0fa94356ad309cff480b3fef9d8cb7b21a641433b"
    if security_utils.get_hash_value(escape(psw)) != hashed_psw:
        return flask.jsonify(status="forbidden"), HTTPStatus.FORBIDDEN

    database = db_utils.DatabaseUtils()
    client_history = {
        "clients": []
    }
    for client_row in database.get_all_clients():
        marketing_row = database.get_marketing_info_by_client_row(client_row)
        client_data = database.convert_client_row_to_json(client_row)
        client_data["marketing"] = database.convert_marketing_row_to_json(marketing_row)
        client_history["clients"].append(client_data)
    return flask.jsonify(client_history), HTTPStatus.OK


@app.route("/api/export/<psw>", methods=["GET"])
def export_all(psw):
    hashed_psw = "b989d62e5533b11cbc3464b0fa94356ad309cff480b3fef9d8cb7b21a641433b"
    if security_utils.get_hash_value(escape(psw)) != hashed_psw:
        return flask.jsonify(status="forbidden"), HTTPStatus.FORBIDDEN

    database = db_utils.DatabaseUtils()
    response_json = {
        "status": "success",
        "advisers": [],
        "clients": [],
        "marketing": []
    }
    for client_row in database.get_all_clients():
        response_json["clients"].append(database.convert_client_row_to_json(client_row))
    for adviser_row in database.get_all_advisers():
        response_json["advisers"].append(database.convert_adviser_row_to_json(adviser_row))
    for marketing_row in database.get_all_marketing_rows():
        marketing_data = database.convert_marketing_row_to_json(marketing_row)
        marketing_data["clientId"] = marketing_row[1]
        response_json["marketing"].append(marketing_data)

    return flask.jsonify(response_json), HTTPStatus.OK