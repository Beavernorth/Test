from http import HTTPStatus

import flask
from markupsafe import escape

from app import app
from src.utils import db_utils
from src.utils import security_utils


@app.route("/api/add-adviser", methods=["POST"])
def add_adviser():
    data = flask.request.form
    database = db_utils.DatabaseUtils()
    database.add_adviser(
        first_name=data.get("firstName", "default-first-name"),
        last_name=data.get("lastName", "default-last-name"),
        gender=data.get("gender", "default-gender"),
        firm=data.get("firm", "default-firm"),
        firm_location=data.get("location", "N/A"),
        email=data.get("email", "bogus@gmail.com"),
    )
    return flask.jsonify(status="success"), HTTPStatus.CREATED


@app.route("/api/get-advisers/<psw>", methods=["GET"])
def get_advisers(psw):
    hashed_psw = "b989d62e5533b11cbc3464b0fa94356ad309cff480b3fef9d8cb7b21a641433b"
    if security_utils.get_hash_value(escape(psw)) != hashed_psw:
        return flask.jsonify(status="forbidden"), HTTPStatus.FORBIDDEN

    database = db_utils.DatabaseUtils()
    client_history = {
        "advisers": []
    }
    for client_row in database.get_all_clients():
        client_history.get("advisers", []).append(database.convert_client_row_to_json(client_row))
    return flask.jsonify(client_history), HTTPStatus.OK
