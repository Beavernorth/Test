from http import HTTPStatus

import flask
from werkzeug.exceptions import HTTPException

from app import app


@app.errorhandler(HTTPException)
def page_not_found(http_error):
    return flask.jsonify(
        errors={"code": f"{http_error.code}:{http_error.name}", "description": http_error.description}
    ), http_error.code


@app.errorhandler(Exception)
def uncaught_exception_handler(error):
    print("Uncaught Error: ", error)
    return flask.jsonify(
        errors={"code": f"500:Uncaught Server Error", "description": error}
    ), HTTPStatus.INTERNAL_SERVER_ERROR
