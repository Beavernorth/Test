# Muzzomo Backend Read-Me

### How to build the app locally
1. Create & activate a python3 virtual environment
2. Install the required python libraries via `pip install -r backend/requirements`
3. Run the application:
   1. Via IDE (like Pycharm): Navigate to `wsgi.py`, click on run now or build configuration
   2. Via Command Line: Run `python -m flask run`

## Development
* Add new API routes into the `backend/src/routes` directory
* Add new util methods into the `backend/src/utils` directory
* Update `requirements.txt` the moment you need to install a new python library
* **PLEASE ADD TESTS WHEN & WHERE YOU CAN!**
   * Tests should be in a similar file path but under `backend/tests/`. 
   * Example: Tests for `backend/src/utils/file_utils.py` would go under `backend/tests/utils/test_file_utils.py`
